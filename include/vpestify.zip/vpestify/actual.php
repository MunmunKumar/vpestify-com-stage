




<?php
require("PHPMailer-5.2.23/PHPMailer-5.2.23/PHPMailerAutoload.php");
$mail = new PHPMailer();



#$mail->IsSMTP();
#$mail->SMTPDebug = 2;
$mail->Host = '69.160.38.3';// specify main and backup server
$mail->SMTPAuth = true; // turn on SMTP authentication
$mail->Username = "noreply@mayankfurniture.in"; // SMTP username
$mail->Password = "!5dE}fD470Id";  // SMTP password
$mail->SMTPSecure = 'tls';
$mail->Port = 587;
$mail->setFrom('noreply@mayankfurniture.in', 'Love from Armenia');
$mail->addReplyTo('noreply@mayankfurniture.in', 'Love from Armenia');
$mail->addAddress('weblifedeveloper@gmail.com', 'Michael Harrison');
$mail->addCC('fwhglobal@gmail.com', 'Michael Harrison');
//$mail->addBCC('bcc@example.com');
$mail->Subject = "You have received feedback from your website!";
$mail->Body = 'This is Testing';

if(!$mail->Send())
{
        echo "Message could not be sent. <p>";
        echo "Mailer Error: " . $mail->ErrorInfo;
        exit;
}else{
        echo "Thank you for contacting us. We will be in touch with you very soon.";
}
?>