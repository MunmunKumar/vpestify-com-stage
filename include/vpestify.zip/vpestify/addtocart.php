
<? 
if($_REQUEST['command']=='add' && $_REQUEST['productid']>0){
		$pid=$_REQUEST['productid'];
		$qty=$_REQUEST['quantity'];
		$psizes=$_REQUEST['sizes'];
		addtocart($pid,$qty,$psizes);
		header("location:cart.php");
		exit();
	}
	?>
    <script language="javascript">
	function addtocart(){
		
		document.form1.productid.value = $('#pid').val();
		document.form1.quantity.value = $('#quantity').val();
		document.form1.sizes.value = $('#prodsize').val();
		document.form1.command.value='add';
		document.form1.submit();
	}
</script>
<form name="form1">
	<input type="hidden" name="productid" />
    <input type="hidden" name="quantity" />
    <input type="hidden" name="sizes" />
    <input type="hidden" name="command" />
</form>