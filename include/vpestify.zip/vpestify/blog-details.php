<?
require_once("includes/dbsmain.inc.php");
ob_start();
include("class/addClass.php");
include("class/fetchClass.php");
$fObj=new Fetch();
$obj=new Add();
$menu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,3');
$fmenu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,4');
$contact=$fObj->contact(CONTACT,'cont_id','1');
@extract($contact);
$logo=$fObj->contact(LOGO,'logo_id','1');
@extract($logo);
$pagename=$fObj->curPageName($_SERVER["SCRIPT_NAME"]);
$cms=$fObj->cmsPage(CMSPAGE,'page_url',$pagename);
@extract($cms);
$css=$fObj->contact(ADMIN,'admin_id',ACCESS_ID);
@extract($css);
$cmsid =$fObj->decode($_REQUEST['cmsid']);
$data=$fObj->prodDetail(PRODUCTS,'prod_status','Enable','prod_id',$cmsid);
@extract($data);
$prod_images=explode(',',$prod_image);
$count=count($prod_images)-1;
$prodname=$fObj->singleRecord(PRODUCTS,prod_name,prod_id,$data['prod_pid']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      
        <title><?=$page_title?></title>
        <meta name="keyword" content="<?=$page_meta_keyword?>">
        <meta name="description" content="<?=$page_meta_description?>">
        <link rel="canonical" href="https://<?=$cont_website?>/" />
        <meta name="author" content="<?=strtoupper($cont_comp_name)?>">
        <meta name="language" content="english">
        <link rel="icon" href="<?=UP_FILES_WS_PATH.'/'.$logo['favicon_icon_image']?>" type="images/favicon-icn.png" sizes="16x16">
     
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet" type="text/css">
      <link href="css/responsive.css" rel="stylesheet" type="text/css">
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link href="css/animate.css" rel="stylesheet">
      <link href="css/icofont.css" rel="stylesheet" type="text/css">
      <link href="css/swiper.css" rel="stylesheet" type="text/css">
      <link href="css/owl.carousel.min.css" rel="stylesheet">
      <link href="css/magnific-popup.css" rel="stylesheet">
      <link rel="stylesheet" href="css/fontawesome.css">
     <link href="css/simplelightbox.min.css" type="text/css" rel="stylesheet">
      <link href="css/demo2.css" rel="stylesheet" type="text/css">
   </head>
   <body>
      <header class="header1">
       <? include("menu.php")?>
      </header>
      <!--================ End Header Area =================-->
      <div id="content-wrapper">
       <section class="sub-head" style="background: url(images/back-bg.jpg); background-position: center;">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="sub-headtext">
                  <h3>Blog Details</h3>
                 <p><a href="index.php">Home</a> <i class="fa fa-arrow-right"></i> Blog Details</p>    
                  </div>
                  <div class="hex-img"></div>
                  
                </div>
              
              </div>
           
           </div>
          </section> 
          
       <div class="container">
        <div class="row">
         <div class="col-md-12">
             <div class="blog-details">
              <img src="images/blog1.jpg">
                 <div class="date-bg">
                     <h6>3 Sept</h6>
                 </div>
                 <ul>
                   <li><i class="fa fa-user"></i> by Admin</li>
                   <li><i class="fa fa-commenting"></i> 3 Comments</li>
                 </ul>
                 <div class="right-links">
                  <ul>
                     <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                     <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                     <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                     </ul>
                 </div>
               <h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h3>
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p> 
                 <div class="blackqutes">
                  <p> <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p> </p>
                 </div>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p> 
           
            <div class="row">
           <div class="col-md-6">
               <div class="blog-details">
                   <h5>Lorem Ipsum is simply dummy text of the printing</h5>
                     <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p> 
                      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p> 
            </div>
           </div>
           <div class="col-md-6">
            <div class="blog-small">
                <img src="images/blog1.jpg">
               </div>
           </div>
            </div>
             <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
           </div>
              </div>
           </div>
          </div>   
          
          
          
          
          
          
          
          
          
         <footer class="footer_01">
            
            
                  <? include("footer.php")?>
         </footer>
         <!--================ End Footer =================-->
      </div>
       
       <button onclick="topFunction()" id="myBtn" title="Go to top"> Top</button>
<script>

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>
       <script>
function openNav() {
    document.getElementById("mySidenav").style.width = "350px";
    document.getElementById("main").style.marginLeft = "350px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
      <script src="js/jquery.min.js"></script>
      <script src="js/jquery.shuffle.min.js"></script>
      <script src="js/custom.js"></script>
      <script src="js/global.js"></script>
      <script src="js/swiper.jquery.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script src="js/jquery.magnific-popup.min.js"></script>
	  <script src="js/jquery.barfiller.js"></script>
   </body>

</html>