<?
require_once("includes/dbsmain.inc.php");
ob_start();
include("class/addClass.php");
include("class/fetchClass.php");
$fObj=new Fetch();
$obj=new Add();
$menu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,3');
$fmenu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,4');
$tmenu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','5');
$contact=$fObj->contact(CONTACT,'cont_id','1');
@extract($contact);
$logo=$fObj->contact(LOGO,'logo_id','1');
@extract($logo);
$pagename=$fObj->curPageName($_SERVER["SCRIPT_NAME"]);
$cms=$fObj->cmsPage(CMSPAGE,'page_url',$pagename);
@extract($cms);
$css=$fObj->contact(ADMIN,'admin_id',ACCESS_ID);
@extract($css);
$mid =$fObj->decode($_REQUEST['mid']);
$pid =$fObj->decode($_REQUEST['pid']);
$prod_title=$fObj->singleRecord(PRODUCTS,prod_title,prod_id,$pid);
$prodname=$fObj->singleRecord(PRODUCTS,prod_name,prod_id,$pid);
$prod_meta_keyword=$fObj->singleRecord(PRODUCTS,prod_meta_keyword,prod_id,$pid);
$prod_meta_description=$fObj->singleRecord(PRODUCTS,prod_meta_description,prod_id,$pid);
$prod_h_image=$fObj->singleRecord(PRODUCTS,prod_header_image,prod_id,$pid);
?><!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
   <title><?=$prod_title?></title>
<meta name="keyword" content="<?=$prod_meta_keyword?>">
<meta name="description" content="<?=$prod_meta_description?>">
<link rel="canonical" href="https://<?=$cont_website?>/" />
<meta name="author" content="<?=strtoupper($cont_comp_name)?>">
<meta name="language" content="english">
    
     <link rel="icon" href="<?=UP_FILES_WS_PATH.'/'.$logo['favicon_icon_image']?>" type="images/favicon-icn.png" sizes="16x16">  
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet" type="text/css">
      <link href="css/responsive.css" rel="stylesheet" type="text/css">
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link href="css/animate.css" rel="stylesheet">
     <link rel="stylesheet" href="css/flexslider.css">
      <link href="css/icofont.css" rel="stylesheet" type="text/css">
      <link href="css/swiper.css" rel="stylesheet" type="text/css">
      <link href="css/owl.carousel.min.css" rel="stylesheet">
      <link href="css/magnific-popup.css" rel="stylesheet">
      <link rel="stylesheet" href="css/fontawesome.css">
     
    
   </head>
   <body>
      <!--================ Header Area =================-->
       <header class="header1">
         
         
         <? include("addtocart.php");include("menu.php")?>
      </header>
      <!--================ End Header Area =================-->
      <div id="content-wrapper">
        <section class="sub-head" style="background: url(images/back-bg.jpg); background-position: center;">
          <div class="container">
           <?
						$mid =$fObj->decode($_REQUEST['mid']);
						$pid =$fObj->decode($_REQUEST['pid']);
						$data=$fObj->prodDetail(PRODUCTS,'prod_status','Enable','prod_id',$pid);
						@extract($data);
						
                    ?>    
            <div class="row">
              <div class="col-md-12">
                <div class="sub-headtext">
                  <h3><?=ucwords($prod_name)?></h3>
                 <p><a href="index.php">Home</a> <i class="fa fa-arrow-right"></i> Product <i class="fa fa-arrow-right"></i><?=ucwords($prod_name)?></p>    
                  </div>
                  <div class="hex-img"></div>
                  
                </div>
              
              </div>
           
           </div>
          </section> 
       
       <div class="cellpadding service_details">
			   <div class="container">
				  <div class="row">
					 <div class="col-sm-12 col-md-4 col-md-push-8 col-lg-3 col-lg-push-9" style="display: none;">
						<aside class="blogAside">
                <?  $page=$fObj->page_name();@extract($page);$i=0;
                foreach($page as $bkey=>$bval){
                @extract($bval);	?>
                <? if($page_is_category=='Yes' && $page_status=='Enable' && $page_type=="Category Page"){ ?>	                            <!-- Begin Panel --><?
                $prod_id=$fObj->singleRecord(PRODUCTS,prod_id,prod_pageid,$page_id);
                $cateMenu=$fObj->cateMenu(PRODUCTS,'prod_status','Enable','prod_pid',$prod_id,'prod_user_id','0','prod_order');
                @extract($cateMenu);
                if(count($cateMenu)>=1){
                ?>
						   <ul class="categoryList normall">
                           
               <li class="activeCat"><a href="#">All Products<i class="fa fa-level-down" aria-hidden="true"></i></a></li>
                <?      
									foreach($cateMenu as $pkey=>$pval){ @extract($pval);
									$scate=$fObj->cateMenu(PRODUCTS,'prod_status','Enable','prod_pid',$pval['prod_id'],'prod_order');
									if(count($scate)>=1){  
									 ?>
             <? } else{ 
						 // If subcategory not available then bellow line will execute?>
              <li><a href="product-detail.php?mid=<?=$fObj->encode($pval['prod_pid'])?>&pid=<?=$fObj->encode($pval['prod_id'])?>"><?=ucwords($prod_name)?></a></li>
                       
              <? } }?> 
							   
						   </ul>
           <? } } }?>
						</aside>
		 </div>
                     
          <?
						$mid =$fObj->decode($_REQUEST['mid']);
						$pid =$fObj->decode($_REQUEST['pid']);
						$data=$fObj->prodDetail(PRODUCTS,'prod_status','Enable','prod_id',$pid);
						@extract($data);
						
         ?>  
                    
					 <div class="col-sm-12 col-md-8">
						<div class="mainServicesContent">
						   <div class="section_1">
                 <img src="<?=UP_FILES_WS_PATH.'/normal/'.$prod_image?>" title="<?=$prod_name?>" alt="<?=$prod_name?>" class="img-responsive">
                 <h3 class="tt-title"><?=ucwords($prod_name)?></h3>
                   <div class="simple-text">

                    <div class="detail" style="padding-top: 0;">
                           <p><?=stripslashes($prod_full_desciption)?></p>
<!--		                 <a href="contact-us.php" class="btn btn-get">Send Enquiry</a>-->
                        </div>
          
           		
					  </div>
				   </div>
				
				</div>
			 </div>
            
            <div class="col-md-4">
                <div class="inquiry">
                  <h3>ARE YOU HAVING TROUBLE WITH PESTS?</h3>
                    <h6>Give us a call: <span>+91-9650539282</span></h6>
                    <p>Or schedule a call with an vPestfy today and get a FREE inspection for:</p>
                    <h6>Contact us today, and get reply quickly!</h6>
                    
                    <div class="form-inquiry">
                     <form>
                        <div class="form-group">
                          <input type="name" class="form-control inquir-type" placeholder="Name...">
                         </div>
                      
                         <div class="form-group">
                          <input type="number" class="form-control inquir-type" placeholder="Mobile No...">
                         </div>
                         <div class="form-group">
                          <input type="text" class="form-control inquir-type" placeholder="Service...">
                         </div>
                         <div class="form-group">
                          <input type="text" class="form-control inquir-type" placeholder="city...">
                         </div>
                         <div class="form-group">
                         <textarea name="message" class="form-control inquir-type" placeholder="Message..." cols="5" rows="3"></textarea>
                         </div>
                         <button type="submit" class="btn btn-submit-now">Submit</button>
                        </form>
                    </div>
                     </div>      
                      </div>          
                          
		  </div>
	   </div>
	</div>
          
         <!--================ Footer =================-->
         <footer class="footer_01">           
	        <? include("footer.php")?>
         </footer>
         <!--================ End Footer =================-->
      </div>
       
     
       <button onclick="topFunction()" id="myBtn" title="Go to top"> Top</button>
<script>

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>
       <script>
function openNav() {
    document.getElementById("mySidenav").style.width = "350px";
    document.getElementById("main").style.marginLeft = "350px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
    
      <script src="js/jquery.min.js"></script>
      <script src="js/jquery.shuffle.min.js"></script>
      <script src="js/custom.js"></script>
      <script src="js/global.js"></script>
      <script src="js/swiper.jquery.min.js"></script>
     <script src="js/jquery.flexslider.js"></script>
      <script src="js/jquery.magnific-popup.min.js"></script>
	  <script src="js/jquery.barfiller.js"></script>
	  

<script>

//Qty
function incrementValue(e) {
  e.preventDefault();
  var fieldName = $(e.target).data('field');
  var parent = $(e.target).closest('div');
  var currentVal = parseInt(parent.find('input[name=' + fieldName + ']').val(), 10);

  if (!isNaN(currentVal)) {
    parent.find('input[name=' + fieldName + ']').val(currentVal + 1);
  } else {
    parent.find('input[name=' + fieldName + ']').val(1);
  }
}

function decrementValue(e) {
  e.preventDefault();
  var fieldName = $(e.target).data('field');
  var parent = $(e.target).closest('div');
  var currentVal = parseInt(parent.find('input[name=' + fieldName + ']').val(), 10);

  if (!isNaN(currentVal) && currentVal > 0) {
    parent.find('input[name=' + fieldName + ']').val(currentVal - 1);
  } else {
    parent.find('input[name=' + fieldName + ']').val(1);
  }
}

$('.qty').on('click', '.button-plus', function(e) {
  incrementValue(e);
});

$('.qty').on('click', '.button-minus', function(e) {
  decrementValue(e);
});



</script>


   </body>

</html>