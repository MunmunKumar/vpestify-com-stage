<div class="row">
               <div class="col-md-12">
                 <div class="produ-heading">
                   <h3>Featured Services</h3>
                     
                   </div>
                   <div class="row">
<? $offers=$fObj->cateMenu(PRODUCTS,"prod_status","Enable",'prod_offer','Yes',"prod_user_id","0","prod_order");@extract($offers);?>
<? foreach($offers as $okey=>$oval){@extract($oval);

?>
                   	<div class="col-md-5">
                         
                      <div class="pr-cont fadeInUp animated">
                      	
                                 <div class="pro-de">
                                       <div class="pro-text">
                                <a href="product-detail.php?mid=<?=$fObj->encode($prod_pid)?>&pid=<?=$fObj->encode($prod_id)?>"><h2><?=ucwords($prod_name)?></h2></a>
<!--
                                <span>MRP: Rs <?=number_format($prod_final_price,2,'.','')?> </span> 
                                <a href="#" onClick="addtocart();" class="add">Add to Cart</a>
-->
                            </div>
                             <a href="product-detail.php?mid=<?=$fObj->encode($prod_pid)?>&pid=<?=$fObj->encode($prod_id)?>">
                             <img  src="<?=UP_FILES_WS_PATH.'/normal/'.$prod_image?>" alt="<?=$prod_name?>" title="<?=$prod_name?>" class="bigimage"></a>
                           
                          </div>
                        </div>
                   </div>
                   <? } 

 ?>
                   
                   <?  
$featuredpro=$fObj->cateMenu(PRODUCTS,"prod_status","Enable",'prod_featured','Yes',"prod_user_id","0","prod_order");
@extract($featuredpro);if($featuredpro){   
$prodname=$fObj->singleRecord(PRODUCTS,'prod_name','prod_id',$featuredpro[0]['prod_pid']);
?>
                   <div class="col-md-7">
                  <div class="row">
                  <? $i=0;
				   
				   foreach($featuredpro as $key=>$val){@extract($val);?>
                     <div class="col-md-6">
                       <div class="pr-cont fadeInUp animated">
                         <div class="pro-de">
                              <div class="pro-text">
                                <a href="product-detail.php?mid=<?=$fObj->encode($prod_pid)?>&pid=<?=$fObj->encode($prod_id)?>"><h2><?=ucwords($prod_name)?></h2></a>
<!--
                                <span>MRP: Rs 50 </span> 
                                <a href="#" class="add">Add to Cart</a>
-->
                            </div>
                             <a href="product-detail.php?mid=<?=$fObj->encode($prod_pid)?>&pid=<?=$fObj->encode($prod_id)?>">
                             <img  src="<?=UP_FILES_WS_PATH.'/normal/'.$prod_image?>" alt="<?=$prod_name?>" title="<?=$prod_name?>" class="bigimage"></a>
                            
                          </div>
                        </div>
                     </div>
                     <? }?>
                      
                      
                      
                            	
                       </div>
                       </div>
                       <? }?>
                   
                   </div>
                  
                 
              </div>
              </div>  