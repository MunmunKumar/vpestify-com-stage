   <div class="container">
     <div class="row">
       <div class="col-md-4">
         <div class="footer-heading">
            <h4>Contact Details</h4>
              <ul class="footer-address">
                <li><i class="fa fa-map-marker"></i>
                   <?=$cont_address?>
                   <?=$cont_city?>
                   <?=$cont_state?>
                   <?=$cont_country?>
                   <?=$cont_pincode?> </li>
                   <li><i class="fa fa-mobile"></i> <?=$cont_cust_supp_number?></li>
                   <li><i class="fa fa-envelope"></i> <a href="mailto:<?=$cont_enquiry_email?>"> 
                    <?=$cont_enquiry_email?></a> </li>
                  </ul>  
          </div>
       </div>
           
       <div class="col-md-3">
           <div class="footer-heading">
               <h4>Quick Links</h4>
                 <ul class="footer-links">
                  <? @extract($fmenu); $i=0;foreach($fmenu as $mkey=>$mval){@extract($mval);$i++;?>
                  <? if($page_is_category=='No' || $page_is_home=='No'){?>
                  <li><a href="<? if(!empty($page_href_url)){?> <?=$page_href_url?> <? }else{?> <?=SITE_WS_PATH?>/<?=$page_url?>.php <? }?>" <? if(!empty($page_href_url)){?>  target="_blank" <? }?>>
                  <i class="fa fa-angle-right"></i>  <?=ucwords($page_name)?>
                    </a></li>
                  <? } }?>
                  <li><a href="terms-and-conditions.php">
                  <i class="fa fa-angle-right"></i>  Terms and Conditions
                    </a></li>
                  
              </ul>  
          </div>
       </div>
                   
       <div class="col-md-5">
           <div class="footer-heading">
               <h4>Get In Touch</h4>
             <iframe src="<?=$cont_google_maps?>" width="100%" height="200" frameborder="0" style="border:0" allowfullscreen></iframe>
          </div>
       </div>
     </div>             
  </div>
  <div class="footer_bottom">
    <div class="container">
      <div class="copyright text-center">
         <p>
          Copyright © <?=$cont_copyright?> Developed by <a target="_blank" href="http://weblifeinfotech.com/"> Weblife Infotech Pvt Ltd </a>
         </p>
      </div>
    </div>
 </div>