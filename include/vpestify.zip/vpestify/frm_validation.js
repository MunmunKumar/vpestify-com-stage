function formvalid()
{
   function trim(str)
{
return str.replace(/^\s*|\s*$/g,'');
}
if(trim(document.getElementById('name').value)==0)
{

     alert("Enter Your Name !");
document.getElementById('name').focus();
return false;
}
if(trim(document.getElementById('comp_name').value)==0)
{
alert("Enter Company Name !");
document.getElementById('comp_name').focus();
return false;
}
if(trim(document.getElementById('address').value)==0)
{
alert("Enter Your Address !");
document.getElementById('address').focus();
return false;
}
if(document.getElementById('country').selectedIndex==0)
{
alert("Select Your Country !");
document.getElementById('country').focus();
return false;
}
var email=document.getElementById('email').value;
if(trim(email)==0)
{
alert('Please enter email id');
document.getElementById('email').focus();
return false;
}
else if(email.indexOf('@')==-1)
{
alert('Invalid email id check (@ or .\'s)');
var len=document.getElementById('email').length;
document.getElementById('email').select(0,len-1)
document.getElementById('email').focus();
return false;
}
else if(email.indexOf('.')==-1)
{
alert('Invalid email id check (@ or .\'s)');
var len=document.getElementById('email').length;
document.getElementById('email').select(0,len-1)
document.getElementById('email').focus();
return false;
}

if(trim(document.getElementById('phone').value)==0)
{
alert("Enter Your Phone No.!");
document.getElementById('phone').focus();
return false;
}
if(isNaN(document.getElementById('phone').value))
{
alert("Phone No. Should Be No.!");
document.getElementById('phone').focus();
return false;
}
  /* if(trim(document.getElementById('fax').value)==0)
{
alert("Enter Fax No. !");
document.getElementById('fax').focus();
return false;
}*/
if(isNaN(document.getElementById('fax').value))
{
alert("Fax No. Should Be No.!");
document.getElementById('fax').focus();
return false;
}
if(trim(document.getElementById('enq_for').value)==0)
{
alert("Enter Service Name!");
document.getElementById('enq_for').focus();
return false;
}

if(trim(document.getElementById('enquiry_detail').value)==0)
{
alert("Write Your Description !");
document.getElementById('enquiry_detail').focus();
return false;
}
}