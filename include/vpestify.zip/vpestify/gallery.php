<?
require_once("includes/dbsmain.inc.php");
ob_start();
include("class/addClass.php");
include("class/fetchClass.php");
$fObj=new Fetch();
$obj=new Add();
$menu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,3');
$fmenu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,4');
$contact=$fObj->contact(CONTACT,'cont_id','1');
@extract($contact);
$logo=$fObj->contact(LOGO,'logo_id','1');
@extract($logo);
$pagename=$fObj->curPageName($_SERVER["SCRIPT_NAME"]);
$cms=$fObj->cmsPage(CMSPAGE,'page_url',$pagename);
@extract($cms);
$css=$fObj->contact(ADMIN,'admin_id',ACCESS_ID);
@extract($css);
$cmsid =$fObj->decode($_REQUEST['cmsid']);
$data=$fObj->prodDetail(PRODUCTS,'prod_status','Enable','prod_id',$cmsid);
@extract($data);
$prod_images=explode(',',$prod_image);
$count=count($prod_images)-1;
$prodname=$fObj->singleRecord(PRODUCTS,prod_name,prod_id,$data['prod_pid']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      
        <title><?=$page_title?></title>
        <meta name="keyword" content="<?=$page_meta_keyword?>">
        <meta name="description" content="<?=$page_meta_description?>">
        <link rel="canonical" href="https://<?=$cont_website?>/" />
        <meta name="author" content="<?=strtoupper($cont_comp_name)?>">
        <meta name="language" content="english">
        <link rel="icon" href="<?=UP_FILES_WS_PATH.'/'.$logo['favicon_icon_image']?>" type="images/favicon-icn.png" sizes="16x16">
     
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet" type="text/css">
      <link href="css/responsive.css" rel="stylesheet" type="text/css">
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link href="css/animate.css" rel="stylesheet">
      <link href="css/icofont.css" rel="stylesheet" type="text/css">
      <link href="css/swiper.css" rel="stylesheet" type="text/css">
      <link href="css/owl.carousel.min.css" rel="stylesheet">
      <link href="css/magnific-popup.css" rel="stylesheet">
      <link rel="stylesheet" href="css/fontawesome.css">
     <link href="css/simplelightbox.min.css" type="text/css" rel="stylesheet">
      <link href="css/demo2.css" rel="stylesheet" type="text/css">
   </head>
   <body>
      <header class="header1">
       <? include("menu.php")?>
      </header>
      <!--================ End Header Area =================-->
      <div id="content-wrapper">
       <section class="sub-head" style="background: url(images/back-bg.jpg); background-position: center;">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="sub-headtext">
                  <h3><?=ucfirst($cms['page_name'])?></h3>
                 <p><a href="index.php">Home</a> <i class="fa fa-arrow-right"></i> <?=ucfirst($cms['page_name'])?></p>    
                  </div>
                  <div class="hex-img"></div>
                  
                </div>
              
              </div>
           
           </div>
          </section> 
          
            <section class="portfolio latest_work_01">
             <? $gallery=$fObj->gallery(GALLERY,'gallery_pid','','gallery_status','Enable','gallery_position');@extract($gallery); if($gallery>=1){?>
           <div class="container">
           
           	
        <div class="row">
         <? $i=0;foreach($gallery as $gkey=>$gval){@extract($gval);?>
         
        <div class="col-md-4">
        <div class="gallery">
			<a href="<?=UP_FILES_WS_PATH.'/'.$gallery_image?>" ><img src="<?=UP_FILES_WS_PATH.'/'.$gallery_image?>" alt="<?=$gallery_title?>" title="<?=$gallery_title?>"></a>
            </div>
            
            </div>    
           <? }?>
           
           
      
          
            </div>
          

			<div class="clear"></div>
		
	</div>


<? }?>
              </section>
               
            <!--================ Footer =================-->
         <footer class="footer_01">
            
            
                  <? include("footer.php")?>
         </footer>
         <!--================ End Footer =================-->
      </div>
       
       <button onclick="topFunction()" id="myBtn" title="Go to top"> Top</button>
<script>

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>
       <script>
function openNav() {
    document.getElementById("mySidenav").style.width = "350px";
    document.getElementById("main").style.marginLeft = "350px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
    
      <script src="js/jquery.min.js"></script>
      <script src="js/jquery.shuffle.min.js"></script>
      <script src="js/custom.js"></script>
      <script src="js/global.js"></script>
      <script src="js/swiper.jquery.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script src="js/jquery.magnific-popup.min.js"></script>
	  <script src="js/jquery.barfiller.js"></script>
	      <script type="text/javascript" src="js/simple-lightbox.js"></script>
      <script>
	$(function(){
		var $gallery = $('.gallery a').simpleLightbox();

		$gallery.on('show.simplelightbox', function(){
			console.log('Requested for showing');
		})
		.on('shown.simplelightbox', function(){
			console.log('Shown');
		})
		.on('close.simplelightbox', function(){
			console.log('Requested for closing');
		})
		.on('closed.simplelightbox', function(){
			console.log('Closed');
		})
		.on('change.simplelightbox', function(){
			console.log('Requested for change');
		})
		.on('next.simplelightbox', function(){
			console.log('Requested for next');
		})
		.on('prev.simplelightbox', function(){
			console.log('Requested for prev');
		})
		.on('nextImageLoaded.simplelightbox', function(){
			console.log('Next image loaded');
		})
		.on('prevImageLoaded.simplelightbox', function(){
			console.log('Prev image loaded');
		})
		.on('changed.simplelightbox', function(){
			console.log('Image changed');
		})
		.on('nextDone.simplelightbox', function(){
			console.log('Image changed to next');
		})
		.on('prevDone.simplelightbox', function(){
			console.log('Image changed to prev');
		})
		.on('error.simplelightbox', function(e){
			console.log('No image found, go to the next/prev');
			console.log(e);
		});
	});
</script>

   </body>

</html>