<!-- JS Cal Start -->
<link rel="stylesheet" type="text/css" media="all" href="<?=DATE_PICKER_WS_PATH?>/jscal/skins/aqua/theme.css" title="Aqua" />
<script type="text/javascript" src="<?=DATE_PICKER_WS_PATH?>/jscal/calendar.js"></script>
<script type="text/javascript" src="<?=DATE_PICKER_WS_PATH?>/jscal/lang/calendar-en.js"></script>
<script type="text/javascript" src="<?=DATE_PICKER_WS_PATH?>/jscal/calendar-setup.js"></script>
<!-- JS Cal End -->