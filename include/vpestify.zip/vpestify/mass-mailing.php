<?
 echo $sender_message='<div style="width:575px; margin: 0 auto; border:4px solid #FF09FF;background:#ffecfc; font-size:14px; font-family:Arial, Helvetica, sans-serif; line-height:1.5em; text-align:justify; border-radius:10px; -moz-border-radius:10px; -webkit-border-radius:10px; padding:10px;">
<p style="margin:0px; padding:0px;text-align:center;"></p>
<p style=" color:#FF00FF; margin-left:200px;">Business Enquiry Information</p>

<div style="background:#FFFFFF; padding:3px;">
<p style=" margin:0; padding:0;"><span style="color:#FF0080; margin:0; padding:0;">  Name : '.$name.'</span> </p>
<p style="margin:0; padding:0;">&nbsp;</p>

</div>


<div style="background:#FFFFFF; padding:3px;">
<p style=" margin:0; padding:0;"><span style="color:#FF0080; margin:0; padding:0;"> Email : '.$email.'</span> </p>
<p style="margin:0; padding:0;">&nbsp;</p>

</div>





<div style="background:#FFFFFF; padding:3px;">
<p style=" margin:0; padding:0;"><span style="color:#FF0080; margin:0; padding:0;"> Mobile : '.$phone.'</span> </p>
<p style="margin:0; padding:0;">&nbsp;</p>

</div>



<div style="background:#FFFFFF; padding:3px;">
<p style=" margin:0; padding:0;"><span style="color:#FF0080; margin:0; padding:0;"> Fax : '.$fax.'</span> </p>
<p style="margin:0; padding:0;">&nbsp;</p>

</div>




<div style="background:#FFFFFF; padding:3px;">
<p style=" margin:0; padding:0;"><span style="color:#FF0080; margin:0; padding:0;"> Subject  : '.$enq_for.'</span> </p>
<p style="margin:0; padding:0;">&nbsp;</p>

</div>




<div style="background:#FFFFFF; padding:3px;">
<p style=" margin:0; padding:0;"><span style="color:#FF0080; margin:0; padding:0;"> Address : '.$address.'</span> </p>
<p style="margin:0; padding:0;">&nbsp;</p>

</div>








<div style="background:#FFFFFF; padding:3px;">
<p style=" margin:0; padding:0;"><span style="color:#FF0080; margin:0; padding:0;">  '.ucfirst($enquiry_detail).'</span> </p>
<p style="margin:0; padding:0;">&nbsp;</p>

</div>
<p>&nbsp;</p>

<p style="margin:0; padding:0;">With Regards</p>
<p style="font-style:italic; font-weight:bold; margin:0px;  color:#FF3399;  text-decoration:underline;">['.$name.']</p>
</div>';


?>


