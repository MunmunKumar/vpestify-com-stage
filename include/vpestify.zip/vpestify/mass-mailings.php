<?
$message='                                <!-- Start Personal -->
                                <div class="personal">

                                    <h2>Personal Data:</h2>
                                   
                                    <ul>
                                    	<li class="col-sm-4">
                                        	<label>Beneficiary:</label>
                                           '.$beneficiary.'
                                        </li>
                                        <li class="col-sm-4">
                                        	<label>Applicant Name:</label>
                                            '.$name.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>Father Name:</label>
                                            '.$fname.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>Mother Name:</label>
                                           '.$mname.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>Annual income of the whole family:</label>
                                           '.$familyincome.'
                                        </li>
	                                </ul>
								
                                </div>                                			
			                    <!-- End Personal -->
                                    
                                <!-- Start Address -->
                                <div class="Address">

                                    <h2>Address: (IN CAPITAL LETTERS)</h2>
                                    
                                    <ul>
                                    	<li class="col-sm-4">
                                        	<label>Present Address According Aadhaar Card: (for correspondence):</label>
                                           '.$appperaddres.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>Permanent address:</label>
                                          '.$apppermanentaddres.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>PIN:</label>
                                         '.$zipcode.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>Mobile Number<span>*</span>:</label>
                                          '.$mobilenumber.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>E-mail address<span>*</span>:</label>
                                            '.$email.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>Applicant Aadhaar Number<span>*</span>:</label>
                                         '.$panid.'
                                        </li>
	                                </ul>
								
                                </div>                                			
			                    <!-- End Address -->

                                <!-- Start Academic -->
                                <div class="Academic">

                                    <h2>Academic Record If Any:</h2>
                                    
                                    <ul>
                                    	<li class="col-sm-4">
                                        	<label>Name of the Examination Passed</label>
                                          '.$exampassed.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>Year of completion</label>
                                            '.$compyear.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>Name of Board/University</label>
                                          '.$universityname.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>Full Marks</label>
                                           '.$fullmarks.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>Marks obtained</label>
                                           '.$markobtained.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>%</label>
                                         '.$percentage.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>University Registration No./ Roll No.</label>
                                           '.$universityrallno.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>Extra Curricular Activities</label>
                                           '.$extraactivities.'
                                        </li>
	                                </ul>
								
                                </div>                                			
			                    <!-- End Academic -->
                                    
                                <!-- Start Applicant -->
                                <div class="Applicant">

                                    <h2>Applicant Bank Details:</h2>
                                    
                                    <ul>
                                    	<li class="col-sm-3">
                                        	<label>BANK NAME</label>
                                            '.$appbankname.'
                                        </li>
                                    	<li class="col-sm-3">
                                        	<label>IFSC CODE</label>
                                            '.$appifsccode.'
                                        </li>
                                    	<li class="col-sm-3">
                                        	<label>ACCOUNT NUMBER</label>
                                           '.$appaccountnumber.'
                                        </li>
                                    	<li class="col-sm-3">
                                        	<label>BENEFICERY NAME</label>
                                           '.$beneficeryname.'
                                        </li>
	                                </ul>
								
                                </div>                                			
			                    <!-- End Applicant -->
                                    
                                <!-- Start Payment -->
                                <div class="Payment">

                                    <h2>Payment Details Fill Here:</h2>
                                    
                                    <ul>
                                    	<li class="col-sm-4">
                                        	<label>APPLICANT MOBILE NO.</label>
                                        '.$appcantmobilenumber.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>UTR NUMBER</label>
                                           '.$appcanturtnumber.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>TRANSACTION ID</label>
                                           '.$appcanttransid.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>TRANSACTION DATE & TIME</label>
                                           '.$appcanttransdatetime.'
                                        </li>
                                    	<li class="col-sm-4">
                                        	<label>PAID AMOUNT</label>
                                            '.$appcantpaidamount.'
                                        </li>
	                                </ul>
								
                                </div>  
                                                              			
			                   
                                
                                <p>

 
';
?>