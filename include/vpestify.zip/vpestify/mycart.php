<?php require_once("includes/dbsmain.inc.php");
ob_start();
include("class/addClass.php");
include("class/fetchClass.php");
$fObj=new Fetch();
$obj=new Add();
$menu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,3');
$fmenu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','2,3');
$contact=$fObj->contact(CONTACT,'cont_id','1');
@extract($contact);
$logo=$fObj->contact(LOGO,'logo_id','1');
@extract($logo);
$pagename=$fObj->curPageName($_SERVER["SCRIPT_NAME"]);
$cms=$fObj->cmsPage(CMSPAGE,'page_url',$pagename);
@extract($cms);
$css=$fObj->contact(ADMIN,'admin_id',ACCESS_ID);
@extract($css);

/*if(isset($_POST['submits'])){
	if(empty($_SESSION['loginid'])){
		header("location:registor.php?opt=ckt");
	}else{
		header("location:shipping-detail.php");
	}
}
*/
?>


   <? 
 if(is_array($_SESSION['cart'])){
            	$max=count($_SESSION['cart']);
				?>
 
  
<?
					global $db;
					$sql="insert into ".ORDERS." set 
					ord_reg_id='".$_SESSION['loginid']."',
					ord_shp_id='$ord_shp_id',
					ord_amount='".get_order_total()."',
					ord_tax='$ord_tax',
					ord_tax_amount='$ord_tax_amount',
					ord_discount='$ord_discount',
					ord_pay_amount='".get_order_total()."',
					orddate=now()";
					$result=$db->prepare($sql);
					$result->execute();	
					$_SESSION['ord_id']= $db->lastInsertId();
								
			
				for($i=0;$i<$max;$i++){
					$pid=$_SESSION['cart'][$i]['productid'];
					$q=$_SESSION['cart'][$i]['qty'];
					$sizes=$_SESSION['cart'][$i]['sizes'];
					$psize=get_product_size($sizes);
					$pname=get_product_name($pid);
					if($q==0) continue;
					
					$sqlordet="insert into ".ORDERSDETAIL." set 
					orddet_ord_id='".$_SESSION['ord_id']."',
					proid='".$pid."',
					prounitprice='".get_price($pid)."',
					prodquantity='".$q."',
					prodsize = '".$psize."',
					prodtotalprice='".get_price($pid)*$q."'
					
					";
					$results=$db->prepare($sqlordet);
					$results->execute();	
					
			 } ?>
    
    
    
    
    
    
  <? $_SESSION['totalamount']=number_format(get_order_total(),2,'.',',');?>
  
 
  <?
  			 unset($_SESSION['cart']);
 			 header("location:invoice.php");
            }
			else{
				header("location:checkout.php");
			}
		?> 
 