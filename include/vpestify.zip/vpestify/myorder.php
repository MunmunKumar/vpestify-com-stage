<?
require_once("includes/dbsmain.inc.php");
ob_start();
include("class/addClass.php");
include("class/fetchClass.php");
$fObj=new Fetch();
$obj=new Add();
$menu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,3');
$fmenu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','2,3');
$contact=$fObj->contact(CONTACT,'cont_id','1');
@extract($contact);
$logo=$fObj->contact(LOGO,'logo_id','1');
@extract($logo);
$pagename=$fObj->curPageName($_SERVER["SCRIPT_NAME"]);
$cms=$fObj->cmsPage(CMSPAGE,'page_url',$pagename);
@extract($cms);
$css=$fObj->contact(ADMIN,'admin_id',ACCESS_ID);
@extract($css);
$ordID=$_SESSION['ord_id'];
$regID=$_SESSION['loginid'];
if(!empty($ordID) && !empty($regID)){
$order=$fObj->orders(ORDERS,'ordid',$ordID);
@extract($order);	
$orderDetail=$fObj->orderDetail(ORDERSDETAIL,'orddet_ord_id',$ordID);	
@extract($orderDetail);
}
$csymbol="&#8377;";
$shipping="50";
$failedOrder = $fObj->failedOrder(ORDERS,'ord_reg_id',$_SESSION['loginid'],'ord_pay_status','Received','ordid','desc');@extract($failedOrder);

?>
<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      
        <title><?=$page_title?></title>
        <meta name="keyword" content="<?=$page_meta_keyword?>">
        <meta name="description" content="<?=$page_meta_description?>">
        <link rel="canonical" href="https://<?=$cont_website?>/" />
        <meta name="author" content="<?=strtoupper($cont_comp_name)?>">
        <meta name="language" content="english">
        <link rel="icon" href="<?=UP_FILES_WS_PATH.'/'.$logo['favicon_icon_image']?>" type="images/favicon-icn.png" sizes="16x16">
     
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet" type="text/css">
      <link href="css/responsive.css" rel="stylesheet" type="text/css">
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link href="css/animate.css" rel="stylesheet">
      <link href="css/icofont.css" rel="stylesheet" type="text/css">
      <link href="css/swiper.css" rel="stylesheet" type="text/css">
      <link href="css/owl.carousel.min.css" rel="stylesheet">
      <link href="css/magnific-popup.css" rel="stylesheet">
      <link rel="stylesheet" href="css/fontawesome.css">
      <link href="css/simplelightbox.min.css" type="text/css" rel="stylesheet">
      <link href="css/demo2.css" rel="stylesheet" type="text/css">


    
   </head>
   <body>
      <header class="header1">
       <? include("menu.php")?>
      </header>
      <!--================ End Header Area =================-->
      <div id="content-wrapper">
               <section class="sub-head" style="background: url(<?=UP_FILES_WS_PATH?>/c0b60c1e83d85625c2523e5832a520ea.jpg); background-position: center; ">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="sub-headtext">
                  <h3><?=ucfirst($cms['page_name'])?></h3>
                 <p><a href="index.php">Home</a> <i class="fa fa-arrow-right"></i> <?=ucfirst($cms['page_name'])?></p>    
                  </div>
                  <div class="hex-img"></div>
                  
                </div>
              
              </div>
           
           </div>
          </section> 
        
        <!-- Begin User Profile -->
        <div class="u_file">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <div class="bg-bx">
                            <ul>
                                <li class="active"><a href="myaccount.php"><i class="fa fa-user-circle" aria-hidden="true"></i> My Profile</a></li>
                                <li><a href="myorder.php"><i class="fa fa-cubes" aria-hidden="true"></i> My Order</a></li>
                                
                                <li><a href="changespass.php"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Change Password</a></li>
                                <li><a href="#"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-9">
                        <div class="bg1-bx">
                            <h5>My Orders</h5>

                            <table>
                                <thead>
                                    <tr>
                                      <tr>
        <th>Order&nbsp;Id</th>
        <th></th>
        <th>Order&nbsp;Date</th>
        <th>Order&nbsp;Amount</th>
        <th>Discount(%)</th>
        <th>Net&nbsp;Amount</th>
        <th>Order&nbsp;Status</th>
        <th>Delivery&nbsp;Date</th>
      </tr>
                                    </tr>
                                </thead>
                                <tbody>
                                    <? foreach($failedOrder as $key=>$val){ @extract($val);?>
      <tr>
        <td><?=$ordid?></td>
        <td>
        <a href="view-order.php?ordid=<?=$ordid?>" >View&nbsp;Order</a> </td>
        <td><?=date('d-m-Y H:i:s',strtotime($ord_pay_date))?></td>
        <td><?=number_format($ord_amount,'2','.','')?></td>
        <td><?=number_format($ord_discount,'2','.','')?></td>
        <td><?=number_format($ord_pay_amount,'2','.','')?></td>
        <td><?=$ord_delivery_status?></td>
        <td><?=date('d-m-Y',strtotime($ord_delivery_date))?></td>
      </tr>
      <? }?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End User Profile -->

         
         <!--================ Footer =================-->
          <footer class="footer_01">
            
            
                
                 <? include("footer.php")?>
         </footer>
         <!--================ End Footer =================-->
      </div>
       
       <button onclick="topFunction()" id="myBtn" title="Go to top"> Top</button>
<script>

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>
       <script>
function openNav() {
    document.getElementById("mySidenav").style.width = "350px";
    document.getElementById("main").style.marginLeft = "350px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
    
      <script src="js/jquery.min.js"></script>
      <script src="js/jquery.shuffle.min.js"></script>
      <script src="js/custom.js"></script>
      <script src="js/global.js"></script>
      <script src="js/swiper.jquery.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script src="js/jquery.magnific-popup.min.js"></script>
	  <script src="js/jquery.barfiller.js"></script>
	  
   </body>

</html>