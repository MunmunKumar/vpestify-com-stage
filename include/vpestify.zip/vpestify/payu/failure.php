<?
//phpinfo();
require_once("../includes/dbsmain.inc.php");
ob_start();
include("../class/addClass.php");
include("../class/fetchClass.php");
$fObj=new Fetch();
$obj=new Add();
$menu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,3');
$fmenu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,4');
$tmenu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','5');
$contact=$fObj->contact(CONTACT,'cont_id','1');
@extract($contact);
$paymentgateway=$fObj->contact(PAYGATEWAY,'merchant_id','1');
@extract($paymentgateway);
$logo=$fObj->contact(LOGO,'logo_id','1');
@extract($logo);
$pagename=$fObj->curPageName($_SERVER["SCRIPT_NAME"]);
$cms=$fObj->cmsPage(CMSPAGE,'page_url',$pagename);
@extract($cms);
$css=$fObj->contact(ADMIN,'admin_id','1');
@extract($css);

$status=$_POST["status"];
$firstname=$_POST["firstname"];
$amount=$_POST["amount"];
$txnid=$_POST["txnid"];
$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$productinfo=$_POST["productinfo"];
$email=$_POST["email"];
$salt=$merchant_salt;
//$salt="MEeTD0SEnH";

If (isset($_POST["additionalCharges"])) {
       $additionalCharges=$_POST["additionalCharges"];
        $retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
        
                  }
	else {	  

        $retHashSeq = $salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;

         }
		 $hash = hash("sha512", $retHashSeq);
  
       if ($hash != $posted_hash) {
	       $msg4="Invalid Transaction. Please try again";
		   }
	   else {

         $msg1="<h1>Your order status is ". $status .".</h1>";
         $msg2="<h4>Your transaction id for this transaction is ".$txnid.". You may try making the payment by clicking the link below.</h4>";
		  $msg3="<h4>Please make payment again <a href='/payu/'>click here</a></h4>";
          
		 } 
		  $msg1="<h1>Your order status is ". $status .".</h1>";
         $msg2="<h4>Your transaction id for this transaction is ".$txnid.". You may try making the payment by clicking the link below.</h4>";
		  $msg3="<h4>Please make payment again <a href='/payu/'>click here</a></h4>";
?>	
<!DOCTYPE html>
<html lang="en">
<head>


<meta https-equiv="Content-Type" content="text/html; charset=iso-8859-1" />




<title>Payment Unsuccess : <?=ucfirst($merchant_comp_name)?></title>

<meta name="description" content="Payment Gateway of <?=ucfirst($merchant_comp_name)?>">

<meta name="keyword" content="Payment Gateway of <?=ucfirst($merchant_comp_name)?>">
<link rel="canonical" href="https://<?=$merchant_website?>/payu/index.php" />
<meta name="author" content="<?=ucfirst($merchant_comp_name)?>">
<meta name="language" content="english">
 


<meta name="copyright" content="<?=ucfirst($merchant_comp_name)?>">
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	


<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" type="text/css">

<link href="css/default.css" rel="stylesheet" type="text/css">
<link href="css/component.css" rel="stylesheet" type="text/css">

</head>

<body oncontextmenu="return false;" ondragstart="return false;" ondragenter="return false;" ondragover="return false;" ondrop="return false;" onselect="return false;" oncopy="return false" onselect="return false" oncontextmenu="return false" onbeforeprint="return false" onafterprint="return false" onselectstart="return false" scroll="auto" onLoad="submitPayuForm()">

 
<div class="hdtop15">
<div class="container"></div>
</div>
<nav class="navbar navbar-default navbar-static-top">
<div class="container">

<div class="navbar-header" style="margin-bottom:-20px;"><a href="http://<?=$merchant_website?>/payu/"><img src="<?=UP_FILES_WS_PATH.'/'.$logo['logo_image']?>" alt="<?=ucfirst($merchant_comp_name)?>" title="<?=ucfirst($merchant_comp_name)?>" style="height:66px; width:330px;"></a>
</div>

<!--/.nav-collapse -->
</div>
</nav>
<div class="clearfix"></div>  














<div class="clearfix"></div>
<div role="main" class="main">
            <section class="page-top" style="background:#000; padding:10px 0px; border-bottom:#F90 solid 5px;  color:#FFF;">
					<div class="container" >
						
						<div class="row" >
							<div class="col-md-12">
								<h1>Payment Unsuccess</h1>
							</div>
						</div>
					</div>
				</section>

				

                                
                                
                                

<!--Sucess Popup -->

							
				  
				<div class="container" style="margin-top:50px; margin-left:10px;">

					

					

					
					<div class="row" >
                   
						<div class="col-md-12" >

							<div class="offset-anchor" id="contact-sent" style=" padding:10px;font-size:18px; ">
                            <p><?=$msg1?></p>
<p><?=$msg2?></p>
<p><?=$msg3?></p>

</div>
                           

							<div class="offset-anchor" id="contact-sent"></div>
							
							 
						
					</div>

				</div>






<div class="clearfix"></div>








<div class="clearfix"></div>










<div class="clearfix"></div>
<!--/.row -->









<div class="clearfix"></div>
<!--/.andoriod -->















</div><!--/.getintouch -->
</div>











<div class="footer14">



<div class="container">


<div class="row">
<div class="col-md-10"><p>Design & Developed By Weblife Infotech Pvt Ltd</p>  </div>
<div class="col-md-2 pull-right">

<div id="14441126772068" class="wE">


</div>

</div>
</div>
</div>
</div>
</div>


    
 
<script type="text/javascript" src="js/responsive_script.js"></script>

</body>
</html>