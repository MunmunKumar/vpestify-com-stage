<?
//phpinfo();
require_once("../includes/dbsmain.inc.php");
ob_start();
include("../class/addClass.php");
include("../class/fetchClass.php");
$fObj=new Fetch();
$obj=new Add();
$menu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,3');
$fmenu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,4');
$tmenu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','5');
$contact=$fObj->contact(CONTACT,'cont_id','1');
@extract($contact);
$paymentgateway=$fObj->contact(PAYGATEWAY,'merchant_id','1');
@extract($paymentgateway);
$logo=$fObj->contact(LOGO,'logo_id','1');
@extract($logo);
$pagename=$fObj->curPageName($_SERVER["SCRIPT_NAME"]);
$cms=$fObj->cmsPage(CMSPAGE,'page_url',$pagename);
@extract($cms);
$css=$fObj->contact(ADMIN,'admin_id','1');
@extract($css);

// Merchant key here as provided by Payu
$MERCHANT_KEY = $merchant_key;

//$MERCHANT_KEY = "pQI3fGqE";
// Merchant Salt as provided by Payu
$SALT = $merchant_salt;

//$SALT = "MEeTD0SEnH";
// End point - change to https://secure.payu.in for LIVE mode
$PAYU_BASE_URL = "https://secure.payu.in";
$action = '';
$posted = array();
if(!empty($_POST)) {
    //print_r($_POST);
  foreach($_POST as $key => $value) {    
    $posted[$key] = $value; 
	
  }
}

$formError = 0;

if(empty($posted['txnid'])) {
  // Generate random transaction id
  $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
} else {
  $txnid = $posted['txnid'];
}
$hash = '';
// Hash Sequence
$hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
if(empty($posted['hash']) && sizeof($posted) > 0) {
  if(
          empty($posted['key'])
          || empty($posted['txnid'])
          || empty($posted['amount'])
          || empty($posted['firstname'])
          || empty($posted['email'])
          || empty($posted['phone'])
          || empty($posted['productinfo'])
          || empty($posted['surl'])
          || empty($posted['furl'])
		  || empty($posted['service_provider'])
  ) {
    $formError = 1;
  } else {
    //$posted['productinfo'] = json_encode(json_decode('[{"name":"tutionfee","description":"","value":"500","isRequired":"false"},{"name":"developmentfee","description":"monthly tution fee","value":"1500","isRequired":"false"}]'));
	$hashVarsSeq = explode('|', $hashSequence);
    $hash_string = '';	
	foreach($hashVarsSeq as $hash_var) {
      $hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';
      $hash_string .= '|';
    }

    $hash_string .= $SALT;


    $hash = strtolower(hash('sha512', $hash_string));
   $action = $PAYU_BASE_URL . '/_payment';
  }
} elseif(!empty($posted['hash'])) {
  $hash = $posted['hash'];
  $action = $PAYU_BASE_URL . '/_payment';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<script>
    var hash = '<?php echo $hash ?>';
    function submitPayuForm() {
      if(hash == '') {
        return;
      }
      var payuForm = document.forms.payuForm;
      payuForm.submit();
    }
  </script>

<meta https-equiv="Content-Type" content="text/html; charset=iso-8859-1" />



<title>Pay Now : <?=ucfirst($merchant_comp_name)?></title>

<meta name="description" content="Payment Gateway of <?=ucfirst($merchant_comp_name)?>">

<meta name="keyword" content="Payment Gateway of <?=ucfirst($merchant_comp_name)?>">
<link rel="canonical" href="https://<?=$merchant_website?>/payu/index.php" />
<meta name="author" content="<?=ucfirst($merchant_comp_name)?>">
<meta name="language" content="english">
 


<meta name="copyright" content="<?=ucfirst($merchant_comp_name)?>">
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	


<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" type="text/css">

<link href="css/default.css" rel="stylesheet" type="text/css">
<link href="css/component.css" rel="stylesheet" type="text/css">

</head>

<body oncontextmenu="return false;" ondragstart="return false;" ondragenter="return false;" ondragover="return false;" ondrop="return false;" onselect="return false;" oncopy="return false" onselect="return false" oncontextmenu="return false" onbeforeprint="return false" onafterprint="return false" onselectstart="return false" scroll="auto" onLoad="submitPayuForm()">

 
<div class="hdtop15">
<div class="container"></div>
</div>
<nav class="navbar navbar-default navbar-static-top">
<div class="container">

<div class="navbar-header" style="margin-bottom:-20px;"><a href="http://<?=$merchant_website?>/payu/"><img src="<?=UP_FILES_WS_PATH.'/'.$logo['logo_image']?>" alt="<?=ucfirst($merchant_comp_name)?>" title="<?=ucfirst($merchant_comp_name)?>" style="height:66px; width:330px;"></a>
</div>

<!--/.nav-collapse -->
</div>
</nav>
<div class="clearfix"></div>  














<div class="clearfix"></div>
<div role="main" class="main">
            <section class="page-top" style="background:#000; padding:10px 0px; border-bottom:#F90 solid 5px;  color:#FFF;">
					<div class="container" >
						
						<div class="row" >
							<div class="col-md-12">
								<h1>Pay Now</h1>
							</div>
						</div>
					</div>
				</section>

				

                                
                                
                                

<!--Sucess Popup -->

							
				  
				<div class="container" style="margin-top:50px; margin-left:100px;">

					

					

					
					<div class="row" >
                   <div class="col-md-3" >&nbsp;</div>
						<div class="col-md-6" >
<?php if($formError) { ?>
							<div class="offset-anchor" id="contact-sent" style=" color: #F00; padding:10px;font-size:18px; text-align:center; ">Please fill all mandatory fields.</div>
                            <? }?>

							<div class="offset-anchor" id="contact-sent"></div>
							
							 <form action="<?php echo $action; ?>" method="post" name="payuForm">
      <input type="hidden" name="key" value="<?php echo $MERCHANT_KEY ?>" />
      <input type="hidden" name="hash" value="<?php echo $hash ?>"/>
      <input type="hidden" name="hash_abc" value="<?php echo $hash_string ?>"/>
      <input type="hidden" name="txnid" value="<?php echo $txnid ?>" />
							  <div class="row">
					  <div class="form-group">
										<div class="col-md-6">
											<label>Enter Amount <span style="color:#F00">*</span></label>
											<input name="amount" value="<?php echo (empty($posted['amount'])) ? '' : $posted['amount'] ?>"  maxlength="100" class="form-control" placeholder="Enter Amount"/>
										</div>
										<div class="col-md-6">
											<label>Enter Name <span style="color:#F00">*</span></label>
                                            <input name="firstname" id="firstname" value="<?php echo (empty($posted['firstname'])) ? '' : $posted['firstname']; ?>"  maxlength="100" class="form-control" placeholder="Enter Name"/>
                                            
										
										</div>
									</div>
								</div>
                                <div class="row">
									<div class="form-group">
										<div class="col-md-6">
											<label>Enter Email <span style="color:#F00">*</span></label>
											<input name="email" id="email" value="<?php echo (empty($posted['email'])) ? '' : $posted['email']; ?>"  maxlength="100" class="form-control" placeholder="Enter Email"/> 
										</div>
										<div class="col-md-6">
											<label>Enter Mobile <span style="color:#F00">*</span></label>
											<input name="phone" value="<?php echo (empty($posted['phone'])) ? '' : $posted['phone']; ?>"  maxlength="12" class="form-control" placeholder="Enter Mobile"/>
										</div>
									</div>
								</div>
                                
                                
                                <div class="row">
									<div class="form-group">
										<div class="col-md-6">
											<label>ZipCode <span style="color:#F00">*</span></label>
											<input name="zipcode" value="<?php echo (empty($posted['zipcode'])) ? '' : $posted['zipcode']; ?>"  maxlength="100" class="form-control" placeholder="ZipCode"/>
										</div>
										<div class="col-md-6">
										
										</div>
									</div>
								</div>
								
								
						<div class="row">
									<div class="form-group">
										<div class="col-md-12">
												<label>Payment for [Write Invoice/Order number] <span style="color:#F00">*</span></label>
											 <input name="productinfo" value="<?php echo (empty($posted['productinfo'])) ? '' : $posted['productinfo']; ?>"  maxlength="100" class="form-control" placeholder="Payment for [ Example : #21619 ]"/>[Please must write Invoice/Order number to track your payment and mail your transaction Id at <?=$merchant_email?> ]
                                          
										</div>
									</div>
								</div>		
                                
                                
								
								
								<div class="row">
									<div class="col-md-12" style="margin-top:50px;">
                                     <input type="hidden" name="surl" value="http://<?=$merchant_website?>/payu/success.php" size="64" />
         <input type="hidden" name="furl" value="http://<?=$merchant_website?>/payu/failure.php" size="64" />
          <input type="hidden" name="curl" value="http://<?=$merchant_website?>/payu/failure.php" size="64" />
         <input type="hidden" name="service_provider" value="payu_paisa" size="64" />
         <input type="hidden" name="lastname" id="lastname" value="<?php echo (empty($posted['lastname'])) ? '' : $posted['lastname']; ?>" />
         <input  type="hidden" name="address1" value="<?php echo (empty($posted['address1'])) ? '' : $posted['address1']; ?>" />
         <input type="hidden" name="address2" value="<?php echo (empty($posted['address2'])) ? '' : $posted['address2']; ?>" />
          <input type="hidden" name="city" value="<?php echo (empty($posted['city'])) ? '' : $posted['city']; ?>" />
          <input type="hidden" name="state" value="<?php echo (empty($posted['state'])) ? '' : $posted['state']; ?>" />
          <input type="hidden" name="country" value="<?php echo (empty($posted['country'])) ? '' : $posted['country']; ?>" />
           <input type="hidden" name="udf1" value="<?php echo (empty($posted['udf1'])) ? '' : $posted['udf1']; ?>" />
          <input type="hidden" name="udf2" value="<?php echo (empty($posted['udf2'])) ? '' : $posted['udf2']; ?>" />
          <input type="hidden" name="udf3" value="<?php echo (empty($posted['udf3'])) ? '' : $posted['udf3']; ?>" />
          <input type="hidden" name="udf4" value="<?php echo (empty($posted['udf4'])) ? '' : $posted['udf4']; ?>" />
          <input type="hidden" name="udf5" value="<?php echo (empty($posted['udf5'])) ? '' : $posted['udf5']; ?>" />
          <input type="hidden" name="pg" value="<?php echo (empty($posted['pg'])) ? '' : $posted['pg']; ?>" />
                                    <?php if(!$hash) { ?>
                
										<input name="submit" type="submit" id="contactFormSubmit" value="Pay Now" class="btn btn-primary btn-lg pull-right" >
                <? }?>
                
									</div>
								</div>
							
						</div>
						<?php /*?><div class="col-md-6" >
                        
                        <div class="row">
									<div class="form-group">
										<div class="col-md-12">
											 <a href="http://weblifeinfotech.com/newpay/" >
                        <img src="emi.jpg" height="300" width="600">
                    </a>
										</div>
									</div>
								</div>
                                
                                <div class="row">
									<div class="form-group">
										<div class="col-md-12" style="margin-left:300px;">
											 <a href="http://weblifeinfotech.com/newpay/" >Click here !!! Pay With EMI</a>
										</div>
									</div>
								</div>
                       
                        </div><?php */?>
                         <div class="col-md-3" >&nbsp;</div>
					</div>

				 </form>
						
					</div>

				</div>






<div class="clearfix"></div>








<div class="clearfix"></div>










<div class="clearfix"></div>
<!--/.row -->









<div class="clearfix"></div>
<!--/.andoriod -->















</div><!--/.getintouch -->
</div>











<div class="footer14">



<div class="container">


<div class="row">
<div class="col-md-10"><p>Design & Developed By Weblife Infotech Pvt Ltd </p> </div>
<div class="col-md-2 pull-right">

<div id="14441126772068" class="wE">


</div>

</div>
</div>
</div>
</div>
</div>


    
 
<script type="text/javascript" src="js/responsive_script.js"></script>

</body>
</html>