<?
require_once("includes/dbsmain.inc.php");
ob_start();
include("class/addClass.php");
include("class/fetchClass.php");
$fObj=new Fetch();
$obj=new Add();
$tblName=PRODUCTS;
$mid =$fObj->decode($_REQUEST['mid']);
$sid =$fObj->decode($_REQUEST['sid']);
$fid =$fObj->decode($_REQUEST['fid']);



if(!empty($sid)){
$serachVal=$sid;
}else{
$serachVal=$mid;
}
$queries= "SELECT * FROM $tblName   where 1 and prod_status='Enable' and prod_pid='$serachVal' order by prod_order";
include("pdopaging.php");
?>
                                
         
                  <div class="Service_Sec">
                     
                     
                     <?
							
            $sqls .= $queries ." LIMIT $start, $records_per_page";          
            $records 	= $db->query($sqls);
            $count  	= $records->rowCount();
            $HTML='';
            if($count > 0)
            {
				$i=0;
                foreach($records as $row) { @extract($row);
				@extract($row);
				
				
				?>
                    <div class="col-md-6 col-sm-12">
                     <div class="border_radius1">
                           <div class="row">
                              <div class="col-md-5 col-sm-5">
                                   <div class="image image-opacity-on-hover image-zoom-on-hover">
                                 <img src="<?=UP_FILES_WS_PATH.'/'.$prod_image?>" alt="<?=$prod_name?>" title="<?=$prod_name?>" class="img-responsive">
                              </div>
                               </div>
                              <div class="col-md-7 col-sm-7">
                                 <div class="content">
                                    <h4 class="sub-title"><?=ucfirst($prod_name)?> </h4>
                                    <div class="simple-text">
                                       <p><?=$prod_small_desciption?>
                                       </p>
                                    </div>
                                 </div>
                              </div>
                               <a href="product-detail.php?mid=<?=$fObj->encode($prod_pid)?>&pid=<?=$fObj->encode($prod_id)?>">
                              <div class="con_serviecs1">
                                 <div class="border_radius">
                                    <i class="icofont icofont-long-arrow-right"></i>
                                 </div>
                                </div>
                               </a>
                           </div>
                        </div>
                     </div>
                     <? } }?>
                      
                      <div class="pagination">
                        <div class="container">
                            <ul>
                            	<li><?=$pagination;?></li>
                            </ul>
                        </div>
                    </div>
                       
                  </div>
                  
          