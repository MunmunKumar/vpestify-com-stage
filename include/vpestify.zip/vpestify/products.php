<?
require_once("includes/dbsmain.inc.php");
ob_start();
include("class/addClass.php");
include("class/fetchClass.php");
$fObj=new Fetch();
$obj=new Add();
$menu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,3');
$fmenu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,4');
$tmenu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','5');
$contact=$fObj->contact(CONTACT,'cont_id','1');
@extract($contact);
$logo=$fObj->contact(LOGO,'logo_id','1');
@extract($logo);
$pagename=$fObj->curPageName($_SERVER["SCRIPT_NAME"]);
$cms=$fObj->cmsPage(CMSPAGE,'page_url',$pagename);
@extract($cms);
$css=$fObj->contact(ADMIN,'admin_id',ACCESS_ID);
@extract($css);

$mid=$_REQUEST['mpid'];
$sid=$_REQUEST['sid'];
$fid=$_REQUEST['fid'];
$mmid =$fObj->decode($_REQUEST['mpid']);
$ssid =$fObj->decode($_REQUEST['sid']);
$ffid =$fObj->decode($_REQUEST['fid']);
$prodname=$fObj->singleRecord(PRODUCTS,prod_name,prod_id,$mmid);
$prod_title=$fObj->singleRecord(PRODUCTS,prod_title,prod_id,$mmid);
$prod_meta_keyword=$fObj->singleRecord(PRODUCTS,prod_meta_keyword,prod_id,$mmid);
$prod_meta_description=$fObj->singleRecord(PRODUCTS,prod_meta_description,prod_id,$mmid);
$prod_h_image=$fObj->singleRecord(PRODUCTS,prod_header_image,prod_id,$mmid);
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?=$prod_title?></title>
    <meta name="description" content="<?=$prod_meta_keyword?>">
    <meta name="keyword" content="<?=$prod_meta_description?>">
    <link rel="canonical" href="https://<?=$cont_website?>/" />
    <meta name="author" content="<?=strtoupper($cont_comp_name)?>">
    <meta name="language" content="english">
    <link rel="icon" href="<?=UP_FILES_WS_PATH.'/'.$logo['favicon_icon_image']?>" type="images/favicon-icn.png" sizes="16x16"> 

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/responsive.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/icofont.css" rel="stylesheet" type="text/css">
    <link href="css/swiper.css" rel="stylesheet" type="text/css">
    <link href="css/owl.carousel.min.css" rel="stylesheet">
    <link href="css/magnific-popup.css" rel="stylesheet">
    <link rel="stylesheet" href="css/fontawesome.css">
    
   </head>
   <body>
      <!--================ Header Area =================-->
       <header class="header1">
           <? include("menu.php")?>
      </header>
      <!--================ End Header Area =================-->
      
      <div id="content-wrapper">
        <section class="sub-head" style="background: url(images/back-bg.jpg); background-position: center;">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="sub-headtext">
                  <h3><?=ucfirst($prodname)?></h3>
                 <p><a href="index.php">Home</a> <i class="fa fa-arrow-right"></i> <?=ucfirst($prodname)?></p>    
                  </div>
                 
                </div>
              
              </div>
           
           </div>
          </section> 
       
       <div class="service_page_02">
            <div class="container">
               <div class="row">
               
                           
              <script type="text/javascript" src="jquery-1.8.0.min.js"></script> 
              <link href="paging.css" rel="stylesheet" type="text/css" />
                    
              <script type="text/javascript">
              $(document).ready(function(){
              	change_page('0');
              });
              function change_page(page_id){
                   $(".flash").show();
                   $(".flash").fadeIn(400).html('Loading <img src="ajax-loader.gif" />');
                   var dataString = 'page_id='+ page_id;
                   $.ajax({
                         type: "POST",
                         url: "product-search-result.php?mid=<?=$mid?>&sid=<?=$sid?>&fid=<?=$fid?>",
                         data: dataString,
                         cache: false,
                         success: function(result){
                         $(".flash").hide();
              			     $("#page_data").html(result);
                         }
                    });
              }
              </script>


              <div id="page_data"></div>
              <span class="flash"></span>


                  
               </div>
           </div>
         </div>
          <!--================ Footer =================-->
          <footer class="footer_01">
            
            
                
                <? include("footer.php")?>
         </footer>
         <!--================ End Footer =================-->
      </div>
       
 
       
       <button onclick="topFunction()" id="myBtn" title="Go to top"> Top</button>
<script>

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>
       <script>
function openNav() {
    document.getElementById("mySidenav").style.width = "350px";
    document.getElementById("main").style.marginLeft = "350px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
    
      <script src="js/jquery.min.js"></script>
      <script src="js/jquery.shuffle.min.js"></script>
      <script src="js/custom.js"></script>
      <script src="js/global.js"></script>
      <script src="js/swiper.jquery.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script src="js/jquery.magnific-popup.min.js"></script>
	  <script src="js/jquery.barfiller.js"></script>
	  
   </body>

</html>