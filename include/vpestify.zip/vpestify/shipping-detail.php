<?php require_once("includes/dbsmain.inc.php");
ob_start();
include("class/addClass.php");
include("class/fetchClass.php");
$fObj=new Fetch();
$obj=new Add();
$menu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,3');
$contact=$fObj->contact(CONTACT,'cont_id','1');
@extract($contact);
$logo=$fObj->contact(LOGO,'logo_id','1');
@extract($logo);
$pagename=$fObj->curPageName($_SERVER["SCRIPT_NAME"]);
$cms=$fObj->cmsPage(CMSPAGE,'page_url',$pagename);
@extract($cms);
$css=$fObj->contact(ADMIN,'admin_id',ACCESS_ID);
@extract($css);




$ordID=$_SESSION['ord_id'];
$regID=$_SESSION['loginid'];
if(isset($_POST['signup'])){
	$count=$obj->counts(SHIPPING,'shp_ord_id',$ordID);
	if($count>=1){
	$reg=$obj->ShpUpdate(SHIPPING,$_POST);
	}else{
	$reg=$obj->Shpsave(SHIPPING,$_POST);
	}
	
}
$shpDetail=$fObj->orders(SHIPPING,'shp_id',$_SESSION['shp_id']);	
@extract($shpDetail);
$csymbol="&#8377;";

?>
<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      
        <title><?=$page_title?></title>
        <meta name="keyword" content="<?=$page_meta_keyword?>">
        <meta name="description" content="<?=$page_meta_description?>">
        <link rel="canonical" href="https://<?=$cont_website?>/" />
        <meta name="author" content="<?=strtoupper($cont_comp_name)?>">
        <meta name="language" content="english">
        <link rel="icon" href="<?=UP_FILES_WS_PATH.'/'.$logo['favicon_icon_image']?>" type="images/favicon-icn.png" sizes="16x16">
          <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet" type="text/css">
      <link href="css/responsive.css" rel="stylesheet" type="text/css">
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link href="css/animate.css" rel="stylesheet">
      <link href="css/icofont.css" rel="stylesheet" type="text/css">
      <link href="css/swiper.css" rel="stylesheet" type="text/css">
      <link href="css/owl.carousel.min.css" rel="stylesheet">
      <link href="css/magnific-popup.css" rel="stylesheet">
      <link rel="stylesheet" href="css/fontawesome.css">
      <link href="css/simplelightbox.min.css" type="text/css" rel="stylesheet">
      <link href="css/demo2.css" rel="stylesheet" type="text/css">

   </head>
   <body>
      <header class="header1">
       <? include("menu.php")?>
      </header>
      <!--================ End Header Area =================-->
      <div id="content-wrapper">
       <section class="sub-head" style="background: url(http://weblifeinfotech.co.in/liveonlineproject/guninaengineers//uploaded_files/c0b60c1e83d85625c2523e5832a520ea.jpg); background-position: center; ">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="sub-headtext">
                  <h3><?=ucfirst($cms['page_name'])?></h3>
                 <p><a href="index.php">Home</a> <i class="fa fa-arrow-right"></i> <?=ucfirst($cms['page_name'])?></p>    
                  </div>
                  <div class="hex-img"></div>
                  
                </div>
              
              </div>
           
           </div>
          </section> 
        
        <!-- Begin User box-->
        <div class="user_bx">
            <div class="container">

                <h2>Shipping Details</h2>
                <p>&nbsp;</p>

                 <form class="callus" method="post">
                  <div class="form-group row">
                    <label for="inputFirstname" class="col-sm-2 col-form-label">Name</label>
                    <div class="col-sm-10 pl-lg-0 pr-lg-0">
                     <input placeholder="Contact Name" name="shp_name" id="shp_name"  value="<?=$shp_name?>" required class="form-control checkout">
                    </div>
                  </div>
                  
                  <div class="form-group row">
                    <label for="inputEmail" class="col-sm-2 col-form-label">Mobile</label>
                    <div class="col-sm-10 pl-lg-0 pr-lg-0">
                      <input  class="form-control checkout" placeholder="Contact Mobile" name="shp_mobile" id="shp_mobile" value="<?=$shp_mobile?>" required maxlength="10" onKeyPress="return isNumberKey(event)">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Address</label>
                    <div class="col-sm-10 pl-lg-0 pr-lg-0">
                     <textarea placeholder="Contact Address " name="shp_address" id="shp_address" required class="form-control checkout"   cols="3" rows="3"><?=$shp_address?></textarea>
                    </div>
                  </div>
                   <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">State</label>
                    <div class="col-sm-10 pl-lg-0 pr-lg-0">
                     <input class="form-control checkout" placeholder="Contact State"  name="shp_state" id="shp_state" value="<?=$shp_state?>" required>
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="inputlastname" class="col-sm-2 col-form-label">City</label>
                    <div class="col-sm-10 pl-lg-0 pr-lg-0">
                      <input type="text" class="form-control checkout" placeholder="Contact City" name="shp_city" id="shp_city" value="<?=$shp_city?>" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputlastname" class="col-sm-2 col-form-label">Country</label>
                    <div class="col-sm-10 pl-lg-0 pr-lg-0">
                      <input  class="form-control checkout"  placeholder="Contact Country" name="shp_country" id="shp_country" value="<?=$shp_country?>" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputlastname" class="col-sm-2 col-form-label">Zip Code</label>
                    <div class="col-sm-10 pl-lg-0 pr-lg-0">
                        <input type="text" class="form-control checkout" placeholder="Contact Zip Code" name="shp_zip" id="shp_zip" value="<?=$shp_zip?>" required>
                    </div>
                  </div>
                  
                  <div class="form-group row">
                    <div class="col-sm-12 pl-lg-0 pr-lg-0">
                      <input type="hidden" name="otp" id="otp" value="<?=$_REQUEST['otp']?>" />
                        <input type="hidden" name="shpId" id="shpId" value="<?=$_SESSION['shp_id']?>" />
                         <input type="hidden" name="ordId" id="ordId" value="<?=$ordID?>" />
                      <button type="submit" class="btn btn-primary"   name="signup" id="signup">Continue</button>
                    </div>
                  </div>
                </form>

            </div>
        </div>
        <!-- End User bx -->
   
         
         <!--================ Footer =================-->
          <footer class="footer_01">
            
            
                
                 <? include("footer.php")?>
         </footer>
         <!--================ End Footer =================-->
      </div>
       
    <script language="javascript" type="text/javascript">
function isNumberKey(evt){
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
     //onKeyPress="return isNumberKey(event)"
      };
</script>   
       <button onclick="topFunction()" id="myBtn" title="Go to top"> Top</button>
<script>

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>
       <script>
function openNav() {
    document.getElementById("mySidenav").style.width = "350px";
    document.getElementById("main").style.marginLeft = "350px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
    
      <script src="js/jquery.min.js"></script>
      <script src="js/jquery.shuffle.min.js"></script>
      <script src="js/custom.js"></script>
      <script src="js/global.js"></script>
      <script src="js/swiper.jquery.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script src="js/jquery.magnific-popup.min.js"></script>
	  <script src="js/jquery.barfiller.js"></script>
	  
   </body>

</html>