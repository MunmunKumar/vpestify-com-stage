<?
require_once("includes/dbsmain.inc.php");
ob_start();
include("class/addClass.php");
include("class/fetchClass.php");
$fObj=new Fetch();
$obj=new Add();
$menu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,3');
$fmenu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,4');
$contact=$fObj->contact(CONTACT,'cont_id','1');
@extract($contact);
$logo=$fObj->contact(LOGO,'logo_id','1');
@extract($logo);
$pagename=$fObj->curPageName($_SERVER["SCRIPT_NAME"]);
$cms=$fObj->cmsPage(CMSPAGE,'page_url',$pagename);
@extract($cms);
$css=$fObj->contact(ADMIN,'admin_id',ACCESS_ID);
@extract($css);
$cmsid =$fObj->decode($_REQUEST['cmsid']);
$data=$fObj->prodDetail(PRODUCTS,'prod_status','Enable','prod_id',$cmsid);
@extract($data);
$prod_images=explode(',',$prod_image);
$count=count($prod_images)-1;
$prodname=$fObj->singleRecord(PRODUCTS,prod_name,prod_id,$data['prod_pid']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      
        <title><?=$page_title?></title>
        <meta name="keyword" content="<?=$page_meta_keyword?>">
        <meta name="description" content="<?=$page_meta_description?>">
        <link rel="canonical" href="https://<?=$cont_website?>/" />
        <meta name="author" content="<?=strtoupper($cont_comp_name)?>">
        <meta name="language" content="english">
        <link rel="icon" href="<?=UP_FILES_WS_PATH.'/'.$logo['favicon_icon_image']?>" type="images/favicon-icn.png" sizes="16x16">
     
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet" type="text/css">
      <link href="css/responsive.css" rel="stylesheet" type="text/css">
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link href="css/animate.css" rel="stylesheet">
      <link href="css/icofont.css" rel="stylesheet" type="text/css">
      <link href="css/swiper.css" rel="stylesheet" type="text/css">
      <link href="css/owl.carousel.min.css" rel="stylesheet">
      <link href="css/magnific-popup.css" rel="stylesheet">
      <link rel="stylesheet" href="css/fontawesome.css">
      <link href="css/simplelightbox.min.css" type="text/css" rel="stylesheet">
      <link href="css/demo2.css" rel="stylesheet" type="text/css">

   </head>
   <body>
      <header class="header1">
       <? include("menu.php")?>
      </header>
      <!--================ End Header Area =================-->
      <div id="content-wrapper">
        <section class="sub-head" style="background: url(http://weblifeinfotech.co.in/liveonlineproject/guninaengineers//uploaded_files/c0b60c1e83d85625c2523e5832a520ea.jpg); background-position: center; ">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="sub-headtext">
                  <h3><?=ucfirst($cms['page_name'])?></h3>
                 <p><a href="index.php">Home</a> <i class="fa fa-arrow-right"></i> <?=ucfirst($cms['page_name'])?></p>    
                  </div>
                  <div class="hex-img"></div>
                  
                </div>
              
              </div>
           
           </div>
          </section> 
        
        <!-- Begin User Profile -->
        <div class="u_file">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 mb-4">
                        <div class="bg-bx">
                            <ul>
                                <li class="active"><a href="myaccount.php"><i class="fa fa-user-circle" aria-hidden="true"></i> My Profile</a></li>
                                <li><a href="myorder.php"><i class="fa fa-cubes" aria-hidden="true"></i> My Order</a></li>
                                <li><a href="shippingaddress.php"><i class="fa fa-truck" aria-hidden="true"></i> Shipping Address</a></li>
                                <li><a href="changespass.php"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Change Password</a></li>
                                <li><a href="#"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-9">
                        <div class="bg1-bx">
                            <h3>Shipping Address</h3>
                            <form action="#">
                                <div class="row">
                                    <div class="col-sm-6 col-md-6">
                                        <p>
                                            <label for="name">Your Name</label>
                                            <input type="text" name="name" value="" placeholder="Your name">
                                        </p>
                                    </div>
                                    <div class="col-sm-6 col-md-6">
                                        <p>
                                            <label for="email">Email ID</label>
                                            <input type="email" name="email" value="" placeholder="info@gmail.com">
                                        </p>
                                    </div>
                                    <div class="col-sm-6 col-md-6">
                                        <p>
                                            <label for="number">10 digit mobile No.</label>
                                            <input type="text" name="number" value="" placeholder="10 digit mobile No.">
                                        </p>
                                    </div>
                                    <div class="col-sm-6 col-md-6">
                                        <p>
                                            <label for="pin">Pin code</label>
                                            <input type="text" name="pin" value="" placeholder="Pin code">
                                        </p>
                                    </div>
                                    <div class="col-sm-6 col-md-6">
                                        <p>
                                            <label for="pin">City</label>
                                            <input type="text" name="pin" value="" placeholder="City/ District/ Town">
                                        </p>
                                    </div>
                                    <div class="col-sm-6 col-md-6">
                                        <p>
                                            <label for="pin">Select State</label>
                                            <select>
                                                <option> Select State</option>
                                                <option> Delhi</option>
                                                <option> U.P</option>
                                                <option>Haryana</option>
                                                <option> Punjab</option>
                                            </select>
                                        </p>
                                    </div>
                                    <div class="col-sm-12 col-lg-12">
                                        <p>
                                            <label>Address</label>
                                            <textarea cols="2" rows="2" placeholder="Address (Area and Street)"></textarea>
                                        </p>
                                    </div>
                                    <div class="col-sm-12 col-lg-12">
                                        <p>
                                            <button type="Submit" class="btn btn-danger btn-lg">Submit</button>
                                        </p>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End User Profile -->         
         <!--================ Footer =================-->
          <footer class="footer_01">
            
            
                
                 <? include("footer.php")?>
         </footer>
         <!--================ End Footer =================-->
      </div>
       
       <div class="container">
        <div class="row">
           <div class="col-md-10">
          <div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
     <div class="queto-form">
         <h3>Contact Form</h3>
              </div>
              
              <form>
               <div class="form-group">
                  <input type="name" class="form-control custom" placeholder="Your Name">
                  </div>
                  <div class="form-group">
                  <input type="email" class="form-control custom" placeholder="Your Email">
                  </div>
                  <div class="form-group">
                  <input type="number" class="form-control custom" placeholder="Your Number">
                  </div>
                  <div class="form-group">
                  <input type="text" class="form-control custom" placeholder="Subject">
                  </div>
                  <div class="form-group">
                <select name="pro" class="form-control custom">
                      <option>Select Product</option>
                      <option>Wooden Pallets</option>
                      <option> Vacuum Packaging</option>
                      <option>Seaworty Plywood Box</option>
                      <option>Two Way wooden Box</option>
                      <option>Aluminum Foil Bag & Packing</option>
                      <option>Pinewood Crates</option>
                      
                      
                      </select>
                  </div>
                   <div class="form-group">
                       <textarea name="mes" class="form-control custom" placeholder="Message" cols="5" rows="5"></textarea>
                  </div>
                  <button type="submit" class="btn btn-info">Submit</button>
                  
              </form>
  </div>

  <div id="main">
    <span style="font-size:30px;cursor:pointer" onclick="openNav()"><img src="images/reach.gif"></span>
  </div>

            </div>
           <div class="col-md-2">
             <ul class="left-social">
                       <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                       <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                       <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                       <li><a href="#"><i class="fa fa-whatsapp"></i></a></li>
                      
                       
                      </ul>
            
            </div>
           </div>
       </div>
       
       <button onclick="topFunction()" id="myBtn" title="Go to top"> Top</button>
<script>

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>
       <script>
function openNav() {
    document.getElementById("mySidenav").style.width = "350px";
    document.getElementById("main").style.marginLeft = "350px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
    
      <script src="js/jquery.min.js"></script>
      <script src="js/jquery.shuffle.min.js"></script>
      <script src="js/custom.js"></script>
      <script src="js/global.js"></script>
      <script src="js/swiper.jquery.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script src="js/jquery.magnific-popup.min.js"></script>
	  <script src="js/jquery.barfiller.js"></script>
	  
   </body>

</html>