<?php
ob_start();
// $email and $message are the data that is being
// posted to this page from our html contact form


$host="131.153.37.2";
$port="587";
$serverEmail="noreply@shivammotor.co.in";
$password = "QGUOlzXDW_m3";

@extract($_POST);
//print_r($_POST);
echo $name = $_REQUEST['name'] ;
echo "<br>";
echo $email = $_REQUEST['email'] ;
echo "<br>";
/////////////Server Detail //////////////////
//echo $host=$outgoingServerName;
echo "<br>";
echo $port="587";
echo "<br>";
//echo $serverEmail=$serverEmail;
echo "<br>";
//echo $password =$password;
echo "<br>";
/////////////Server Detail End//////////////////
echo $sendTo="$sendToCC";
//echo $sendTo="weblifedeveloper@gmail.com";
echo "<br>";
echo $sendToName=$sendToName;
echo "<br>";
// When we unzipped PHPMailer, it unzipped to
// public_html/PHPMailer_5.2.0
require("PHPMailer/PHPMailerAutoload.php");
//$message="only for testing";
include("mass-mailing.php");
$mail = new PHPMailer();

// set mailer to use SMTP
$mail->IsSMTP();

// As this email.php script lives on the same server as our email server
// we are setting the HOST to localhost
$mail->Host = $host; // specify main and backup server

#$mail->SMTPAuth = true; // turn on SMTP authentication
$mail->Port = $port;
// When sending email using PHPMailer, you need to send from a valid email address
// In this case, we setup a test email account with the following credentials:
// email: user@example.com
// pass: password
$mail->Username = $serverEmail; // SMTP username
$mail->Password = $password; // SMTP password
//$mail->SMTPDebug = 2;
// $email is the user's email address the specified
// on our contact us page. We set this variable at
// the top of this page with:
// $email = $_REQUEST['email'] ;
$mail->setFrom($email, ucwords($name));
// below we want to set the email address we will be sending our email to.
$mail->AddAddress($sendTo, $sendToName);
// cc.
//$mail->addCC($sendToCC, $sendToName);
// set word wrap to 50 characters
$mail->WordWrap = 50;
// set email format to HTML
//$mail->IsHTML(true);

$mail->Subject = "Enquiry for $enq_for from Weblife Infotech Pvt Ltd [ $domain_name ] ";

// $message is the user's message they typed in
// on our contact us page. We set this variable at
// the top of this page with:
// $message = $_REQUEST['message'] ;
//$mail->msgHTML(file_get_contents("mass-mailing.php"), dirname(__FILE__));
$mail->Body = $message;
$mail->AltBody ="Name    : {$name}\n\n Email   : {$email}\n\n Message : {$message}";

if(!$mail->Send())
{
echo "Message could not be sent. <p>";
echo "Mailer Error: " . $mail->ErrorInfo;
}else{
header("location:thanks.php");	
}
?>
