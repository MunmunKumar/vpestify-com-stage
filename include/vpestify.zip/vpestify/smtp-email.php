<?php
ob_start()
$host="svr165.edns1.com";
$port="587";

@extract($_POST);
$aurl = str_replace("www.","", $domain_name); 
$burl = str_replace("http://","", $aurl);
$serverEmail = str_replace("https://","", $burl); 
$durl = "noreply@".$curl; 
$pass = substr($curl,0,6);
$password =$pass."!@#$%^";


//$serverEmail="user@lalajigroup.co.in";
//$password = "8,e50b_x,]eA";

@extract($_POST);
$sender_name = $_REQUEST['name'];
$sender_email = $_REQUEST['email'];
$receiver_name = $_REQUEST['sendToName'];
$receiver_email = $_REQUEST['sendToCC'];
include("mass-mailing.php");
require("PHPMailer/PHPMailerAutoload.php");
$mail = new PHPMailer();
$mail->IsSMTP();
$mail->Host = $host; // specify main and backup server
$mail->Port = $port;
$mail->Username = $serverEmail; // SMTP username
$mail->Password = $password; // SMTP password
$mail->setFrom($sender_email, $sender_name);
$mail->addReplyTo($sender_email, $sender_name);
$mail->addAddress($receiver_email, $receiver_name);
$mail->WordWrap = 50;
$mail->IsHTML(true);
$mail->Subject = $sender_subject;
//$mail->msgHTML(file_get_contents("mass-mailing.php"), dirname(__FILE__));
$mail->Body = $sender_message;
$mail->AltBody ="Name    : {$name}\n\n Email   : {$email}\n\n Message : {$message}";

if(!$mail->Send())
{
        echo "Message could not be sent. <p>";
        echo "Mailer Error: " . $mail->ErrorInfo;
        exit;
}else{
		header("location:thanks.php");	
        echo "Thank you for contacting us. We will be in touch with you very soon.";
}
?>

