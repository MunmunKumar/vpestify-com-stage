<?
require_once("includes/dbsmain.inc.php");
ob_start();
include("class/addClass.php");
include("class/fetchClass.php");
$fObj=new Fetch();
$obj=new Add();
$menu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,3');
$fmenu=$fObj->menu(CMSPAGE,'page_status','Enable','page_orders','page_display','1,4');
$contact=$fObj->contact(CONTACT,'cont_id','1');
@extract($contact);
$logo=$fObj->contact(LOGO,'logo_id','1');
@extract($logo);
$pagename=$fObj->curPageName($_SERVER["SCRIPT_NAME"]);
$cms=$fObj->cmsPage(CMSPAGE,'page_url',$pagename);
@extract($cms);
$css=$fObj->contact(ADMIN,'admin_id',ACCESS_ID);
@extract($css);
$cmsid =$fObj->decode($_REQUEST['cmsid']);
$data=$fObj->prodDetail(PRODUCTS,'prod_status','Enable','prod_id',$cmsid);
@extract($data);
$prod_images=explode(',',$prod_image);
$count=count($prod_images)-1;
$prodname=$fObj->singleRecord(PRODUCTS,prod_name,prod_id,$data['prod_pid']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      
        <title><?=$page_title?></title>
        <meta name="keyword" content="<?=$page_meta_keyword?>">
        <meta name="description" content="<?=$page_meta_description?>">
        <link rel="canonical" href="https://<?=$cont_website?>/" />
        <meta name="author" content="<?=strtoupper($cont_comp_name)?>">
        <meta name="language" content="english">
        <link rel="icon" href="<?=UP_FILES_WS_PATH.'/'.$logo['favicon_icon_image']?>" type="images/favicon-icn.png" sizes="16x16">
     
      <link href="css/style.css" rel="stylesheet" type="text/css">
      <link href="css/responsive.css" rel="stylesheet" type="text/css">
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link href="css/animate.css" rel="stylesheet">
      <link href="css/icofont.css" rel="stylesheet" type="text/css">
      <link href="css/swiper.css" rel="stylesheet" type="text/css">
      <link href="css/owl.carousel.min.css" rel="stylesheet">
      <link rel="stylesheet" href="css/fontawesome.css">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   </head>
   <body>
      <header class="header1">
       <? include("menu.php")?>
      </header>
      <!--================ End Header Area =================-->
      <div id="content-wrapper">
       <section class="sub-head" style="background: url(<?=UP_FILES_WS_PATH.'/'.$cms['page_header_image']?>)">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="sub-headtext">
                  <h3><?=ucfirst($cms['page_name'])?></h3>
                 <p><a href="index.php">Home</a> <i class="fa fa-arrow-right"></i> <?=ucfirst($cms['page_name'])?></p>    
                  </div>
                  <div class="hex-img"></div>
                  
                </div>
              
              </div>
           
           </div>
          </section> 
        <section class="inner-about">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
              <div class="about-content">
                 <h3>Terms of Use</h3>
                                  <p>www.Peenal.com  is owned and operated by GUNINA ENGINEERS, a company incorporated under the laws of India. Your use of the Website and services and tools are governed by the following terms and conditions ("Terms of Use") as applicable to the Website including the applicable policies which are incorporated herein by way of reference. If you transact on the Website, You shall be subject to the policies that are applicable to the Website for such transaction. By mere use of the Website, You shall be contracting with GUNINA ENGINEERS and these terms and conditions including the policies constitute your binding obligations, with GUNINA ENGINEERS. For the purpose of these Terms of Use, wherever the context so requires "You" or "User" shall mean any natural or legal person who has agreed to become a buyer on the Website by providing Registration Data while registering on the Website as Registered User using the computer systems.  </p>				    			
								
                                
                                <p>www.Peenal.com  allows the User to surf the Website or making purchases without registering on the Website. The term "We", "Us", "Our" shall mean GUNINA ENGINEERS When You use any of the services provided by Us through the Website, including but not limited to, (e.g. Product Reviews, Seller Reviews), You will be subject to the rules, guidelines, policies, terms, and conditions applicable to such service, and they shall be deemed to be incorporated into this Terms of Use and shall be considered as part and parcel of this Terms of Use. We reserve the right, at our sole discretion, to change, modify, add or remove portions of these Terms of Use, at any time without any prior written notice to you. It is your responsibility to review these Terms of Use periodically for updates / changes. Your continued use of the Website following the posting of changes will mean that you accept and agree to the revisions. As long as you comply with these Terms of Use, We grant you a personal, non-exclusive, non-transferable, limited privilege to enter and use the Website.</p>		
                              
                                
                               <p>When You use any of the services provided by Us through the Website, including but not limited to, (e.g. Product Reviews, Seller Reviews), You will be subject to the rules, guidelines, policies, terms, and conditions applicable to such service, and they shall be deemed to be incorporated into this Terms of Use and shall be considered as part and parcel of this Terms of Use. We reserve the right, at our sole discretion, to change, modify, add or remove portions of these Terms of Use, at any time without any prior written notice to you. It is your responsibility to review these Terms of Use periodically for updates / changes. Your continued use of the Website following the posting of changes will mean that you accept and agree to the revisions. As long as you comply with these Terms of Use, We grant you a personal, non-exclusive, non-transferable, limited privilege to enter and use the Website.</p>
                               
                               <p>ACCESSING, BROWSING OR OTHERWISE USING THE SITE INDICATES YOUR AGREEMENT TO ALL THE TERMS AND CONDITIONS UNDER THESE TERMS OF USE, SO PLEASE READ THE TERMS OF USE CAREFULLY BEFORE PROCEEDING.</p>
								
                <h3>Privacy Policy</h3>
                                  <p>For us privacy for our valued customer is very important. We strongly believe that the personal information of our customers should not be shared with the third party without the prior consent or request from the customer. Privacy is the right of an individual and at GUNINA ENGINEERS the information of the customer such as contact no., email, addresses etc is used only for the internal purpose and not for sale. Your contact information is stored in our database and is only used to contact you during the course of your stay with us for sharing the status of your room bookings with us and then after for announcement of our latest deals and news etc. We at GUNINA ENGINEERS condemn the unauthorized reach and misuse and/or disclosure of the personal information of the customer and we have strict guidelines and high security features to prevent the same. Any changes in our 'Privacy Policy' will be posted here on the website. SECURE ONLINE PAYMENTS.</p>				    			
								
                                
                                <p>The visitor on our website please take a note that your name, email address and other personal information submitted on our website may be stored with us and may also appear on the website. Like other platforms our server log files also receives general information such as IP address of the visitor, cookie etc. For the financial transactions by credit card GUNINA ENGINEERS uses a 3rd party secure payment gateway provided by "PayU" and the credit card details are 'not stored' with GUNINA ENGINEERS, instead the information is securely stored and encrypted with Visa/MasterCard. Smart Cookies</p>		
                                
                                <p>We use 'Cookies' to keep track of your current shopping session to personalize your experience and so that you may retrieve your shopping cart at any time. 'Cookies' are tiny text files which our Website places on your computer's hard drive to store information about your shopping session and to identify your computer.</p>
                                
                                
                                <h3>Return, Refund and Cancellation Policy</h3>
                                <p>After placing the order customer can cancel the order within 4 hour if he/she wish to. And in case of customer request for Refund, it will be processed through same mode within 7 working days. Products can be returned within 24 hours from the day of delivery.</p>
                              
                  </div>  
                  
                  
                </div>
              </div>              
            </div>
          </section> 
           
       
          <!--================ Footer =================-->
         <footer class="footer_01">
            
                 <? include("footer.php")?>
         </footer>
         <!--================ End Footer =================-->
      </div>
       
     
       
       <button onclick="topFunction()" id="myBtn" title="Go to top"> Top</button>
<script>

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>
       <script>
function openNav() {
    document.getElementById("mySidenav").style.width = "350px";
    document.getElementById("main").style.marginLeft = "350px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
       
    
      <script src="js/bootstrap.min.js"></script>
      <script src="js/jquery.min.js"></script>
      <script src="js/jquery.shuffle.min.js"></script>
      <script src="js/custom.js"></script>
      <script src="js/global.js"></script>
      <script src="js/swiper.jquery.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      
	  <script src="js/jquery.barfiller.js"></script>
	  
   </body>


</html>